#!/bin/bash 
echo "Hello World, the answer is $1"
sleep 3s
echo "$2 Bye world!"

