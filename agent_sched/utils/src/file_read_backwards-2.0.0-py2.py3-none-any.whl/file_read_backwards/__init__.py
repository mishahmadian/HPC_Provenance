# -*- coding: utf-8 -*-

from .file_read_backwards import FileReadBackwards  # noqa: F401

__author__ = """Robin Robin"""
__email__ = 'robinsquare42@gmail.com'
__version__ = '2.0.0'
