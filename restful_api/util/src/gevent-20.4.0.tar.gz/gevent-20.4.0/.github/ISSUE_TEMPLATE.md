* gevent version:
* Python version: Please be as specific as possible: "cPython 2.7.9 downloaded from python.org"
* Operating System: Please be as specific as possible: "Raspbian (Debian Linux 8.0 Linux 4.9.35-v7+  armv7l)"

### Description:

**REPLACE ME**: What are you trying to get done, what has happened, what went wrong, and what did you expect?

```
Remember to put tracebacks in literal blocks
```

### What I've run:

**REPLACE ME**: Paste short, self contained, correct example code (sscce.org), tracebacks, etc, here


```python
"Put python code in python blocks"
```
