==========================================
 :mod:`gevent.lock` -- Locking primitives
==========================================

.. automodule:: gevent.lock
    :members:
