==================================================
 :mod:`gevent._socket2` -- Python 2 socket module
==================================================

.. automodule:: gevent._socket2
    :members:
