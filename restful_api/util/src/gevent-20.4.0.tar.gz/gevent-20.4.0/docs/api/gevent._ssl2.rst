=================================================================================
 :mod:`gevent._ssl2` -- SSL wrapper for socket objects on Python 2.7.8 and below
=================================================================================

.. automodule:: gevent._ssl2
    :members:
