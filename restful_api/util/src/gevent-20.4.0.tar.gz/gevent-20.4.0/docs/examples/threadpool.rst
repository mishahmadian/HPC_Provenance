=============================
Example threadpool.py
=============================
.. literalinclude:: ../../examples/threadpool.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/threadpool.py>`_

