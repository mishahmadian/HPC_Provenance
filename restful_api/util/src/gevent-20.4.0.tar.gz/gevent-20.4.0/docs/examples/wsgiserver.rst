=============================
Example wsgiserver.py
=============================
.. literalinclude:: ../../examples/wsgiserver.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/wsgiserver.py>`_

