=============================
Example unixsocket_server.py
=============================
.. literalinclude:: ../../examples/unixsocket_server.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/unixsocket_server.py>`_

