=============================
Example psycopg2_pool.py
=============================
.. literalinclude:: ../../examples/psycopg2_pool.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/psycopg2_pool.py>`_

